# -*- coding: utf-8 -*-
#------------------------------------------------------------
#------------------------------------------------------------
# License: GPL (http://www.gnu.org/licenses/gpl-3.0.html)
# Based on code from youtube addon
#------------------------------------------------------------

import os
import sys
import plugintools
import xbmc,xbmcaddon
from addon.common.addon import Addon

addonID = 'plugin.video.motor99'
addon = Addon(addonID, sys.argv)
local = xbmcaddon.Addon(id=addonID)
icon = local.getAddonInfo('icon')

YOUTUBE_CHANNEL_ID1 = "Formula1"
YOUTUBE_CHANNEL_ID2 = "wrc"
YOUTUBE_CHANNEL_ID3 = "laf1es"
YOUTUBE_CHANNEL_ID4 = "UC02PCqYtubE_cDaKnqt8jfg"
YOUTUBE_CHANNEL_ID5 = "UCLKDc9r7EjOtfOpytVbpDyg"
YOUTUBE_CHANNEL_ID6 = "FIAFormulaE"
YOUTUBE_CHANNEL_ID7 = "DTMinternational"
YOUTUBE_CHANNEL_ID8 = "UCQKfKMmPwhSMF5dhlvEqCsQ"
YOUTUBE_CHANNEL_ID9 = "MotoGP"


# Entry point
def run():
    plugintools.log("motor99.run")
    
    # Get params
    params = plugintools.get_params()
    
    if params.get("action") is None:
        main_list(params)
    else:
        pass
    
    plugintools.close_item_list()

# Main menu
def main_list(params):
    plugintools.log("motor99.main_list "+repr(params))

    plugintools.add_item( 
        #action="", 
        title="F1",
        url="plugin://plugin.video.youtube/user/"+YOUTUBE_CHANNEL_ID1+"/",
        thumbnail="https://4.bp.blogspot.com/-bcFnq1jH9i8/WOO6pEkyJ-I/AAAAAAAAbPQ/jARYtS2hW7Epbdx9o1FMEBeunJvlWb7LgCLcB/s1600/f1.png",
		fanart="https://2.bp.blogspot.com/-ZUKPGAc_AsM/WOIsO_YQfBI/AAAAAAAAbK4/jTR1ONZgLsIk2K0DSdi2eyOE9Yv_Y1LWACLcB/s1600/formula_1_track_aerial_view-wallpaper-1920x1080.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="One Grand Prix",
        url="plugin://plugin.video.youtube/channel/"+YOUTUBE_CHANNEL_ID4+"/",
        thumbnail="https://3.bp.blogspot.com/-P_XWEYdnJHA/WOO6HnOBUGI/AAAAAAAAbPI/ryLFh6JHWS8Qej_xlUSFImfzB6RQFUfIgCLcB/s1600/f1one.png",
		fanart="https://2.bp.blogspot.com/-ZUKPGAc_AsM/WOIsO_YQfBI/AAAAAAAAbK4/jTR1ONZgLsIk2K0DSdi2eyOE9Yv_Y1LWACLcB/s1600/formula_1_track_aerial_view-wallpaper-1920x1080.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="WRC",
        url="plugin://plugin.video.youtube/user/"+YOUTUBE_CHANNEL_ID2+"/",
        thumbnail="https://4.bp.blogspot.com/-0qMIssKqlh8/WOO3cvFrZpI/AAAAAAAAbO0/Lt-xTFuTqdogY1mGx3rKEiJzFIIRMeyDgCLcB/s1600/WRC.png",
    	fanart="https://4.bp.blogspot.com/-A4lo468Vwqg/WOIzy1FwgDI/AAAAAAAAbLY/UAZw9u-Jc2Qc_QuKWoLBnVxWZQ96q3ybQCLcB/s1600/wc1788960.jpg",
		folder=True )

    plugintools.add_item( 
        #action="", 
        title="SoyMotor",
        url="plugin://plugin.video.youtube/user/"+YOUTUBE_CHANNEL_ID3+"/",
        thumbnail="https://3.bp.blogspot.com/-Vzl_jNdMt7Y/WOO3QX51ClI/AAAAAAAAbOw/pllRmOti9z0bEhflLO5-fOIP9dTVsv1EwCLcB/s1600/soymotor.png",
    	fanart="",
		folder=True )

    plugintools.add_item( 
        #action="", 
        title="Nascar",
        url="plugin://plugin.video.youtube/playlist/PLtc57NTUizP4FFPP6c_Xkp8NDvjhIw3Rj/",
        thumbnail="https://1.bp.blogspot.com/-8NIi_bXPE6Y/WOO42OsmLQI/AAAAAAAAbPA/PuOFmINsyU81mY9VCoQaxnzW1LSSMLT-ACLcB/s1600/nascar.png",
    	fanart="https://4.bp.blogspot.com/-DIBrK1pgUDQ/WON27s0LHWI/AAAAAAAAbM0/yPGqTKx5bTM5ON6pJFXcu_Z-HBSg_xazgCLcB/s1600/Nascar-Race-War.jpg",
		folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="GT4",
        url="plugin://plugin.video.youtube/channel/"+YOUTUBE_CHANNEL_ID5+"/",
        thumbnail="https://1.bp.blogspot.com/--a0BTGbYrvI/WOOkBhYOriI/AAAAAAAAbOM/n8Srau6rAKcnNtp3xltLfxwtgIQIrJ5DACLcB/s1600/gt42.png",
    	fanart="https://4.bp.blogspot.com/-flWb4l6LLIU/WON_X04gBkI/AAAAAAAAbNY/f344C4KEyLYrpxmculHZys-lJfXg3DZCgCLcB/s1600/gt4-series-race-racing-g-t-rally-grand-prix-supercar-0Yjv.jpg",
		folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="Formula E",
        url="plugin://plugin.video.youtube/user/"+YOUTUBE_CHANNEL_ID6+"/",
        thumbnail="https://4.bp.blogspot.com/-_iBxROf68zs/WOO4Wmd8R8I/AAAAAAAAbO8/F314pmeuct0Amvj_WR6XJxPNrRKainNDACLcB/s1600/formula%2Be.png",
    	fanart="https://1.bp.blogspot.com/-BOrvvzz5beo/WOOBzE-T3sI/AAAAAAAAbNw/HyoEsncQD0MWKBrDhRIPc265yd56NagKACLcB/s1600/ds-virgin-16-17-2.jpg",
		folder=True )

    plugintools.add_item( 
        #action="", 
        title="DTM",
        url="plugin://plugin.video.youtube/user/"+YOUTUBE_CHANNEL_ID7+"/",
        thumbnail="https://3.bp.blogspot.com/-83zc0sPPxVE/WOO9sJOpPhI/AAAAAAAAbPc/c0Cvr9xhVNwueZ9AtxYtWUd-a2ykoM-ngCLcB/s1600/dtm.png",
    	fanart="https://1.bp.blogspot.com/-sInGT_rOHV8/WOO97-gS1xI/AAAAAAAAbPg/C0ivz9K5eYsQXdIG1lQALz7u_VgVOZkqgCLcB/s1600/cars_tuning_BMW_M3_DTM_Concept_1920x1200.jpg",
		folder=True )		

    plugintools.add_item( 
        #action="", 
        title="WTCC",
        url="plugin://plugin.video.youtube/channel/"+YOUTUBE_CHANNEL_ID8+"/",
        thumbnail="https://2.bp.blogspot.com/-UYGlcp7-BNI/WOO_KsDuzEI/AAAAAAAAbPo/nDjyfYpa53I80nrhy7JBbnwTSFAd0cZJQCLcB/s1600/wtcc.png",
    	fanart="https://2.bp.blogspot.com/-CFk7v72lO5Q/WOO_LMoLCiI/AAAAAAAAbPs/3kMbiJUv_xkS7fyU6sLCtoUfFzdwF236QCLcB/s1600/wallpaper-1764607.jpg",
		folder=True )	

    plugintools.add_item( 
        #action="", 
        title="MotoGP",
        url="plugin://plugin.video.youtube/user/"+YOUTUBE_CHANNEL_ID9+"/",
        thumbnail="https://2.bp.blogspot.com/-GEk0m969hdo/WOPDDhYhyXI/AAAAAAAAbP4/Y7wgq239NfsYbzOFd2kNtb5dB1J4sFcUwCLcB/s1600/motogp.png",
    	fanart="https://4.bp.blogspot.com/-aaksYwlqINU/WOPDERTNgWI/AAAAAAAAbP8/pQtxsQ-gUPE4ul2UIdhkKSkqm5BrAauuQCLcB/s1600/malasia-test-motogp-2016.jpg",
		folder=True )	
		
run()